package com.example.busgoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class AvailableBus extends AppCompatActivity {

    LinearLayout availBus1, availBus2, availBus3;
    TextView logout, backAvail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_available_bus);

        availBus1 = findViewById(R.id.availBus1);
        availBus2 = findViewById(R.id.availBus2);
        availBus3 = findViewById(R.id.availBus3);

        Bundle extras = getIntent().getExtras();
        String departDate = extras.getString("sDate");
        String destination = extras.getString("destination");
        String departTime = extras.getString("departTime");
        String rSeats = extras.getString("reservedSeats");
        int reservedSeats = Integer.parseInt(rSeats);

        availBus1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(AvailableBus.this, "Please input your Personal Information", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), PersonalInfo.class);
                intent.putExtra("departDate", departDate);
                intent.putExtra("destination", destination);
                intent.putExtra("departTime", departTime);
                intent.putExtra("reservedSeats", reservedSeats);
                intent.putExtra("chooseBus", "Bus 1");
                startActivity(intent);
                finish();
            }
        });

        availBus2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(AvailableBus.this, "Please input your Personal Information", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), PersonalInfo.class);
                intent.putExtra("departDate", departDate);
                intent.putExtra("destination", destination);
                intent.putExtra("departTime", departTime);
                intent.putExtra("reservedSeats", reservedSeats);
                intent.putExtra("chooseBus", "Bus 2");
                startActivity(intent);
                finish();
            }
        });

        availBus3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(AvailableBus.this, "Please input your Personal Information", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), PersonalInfo.class);
                intent.putExtra("departDate", departDate);
                intent.putExtra("destination", destination);
                intent.putExtra("departTime", departTime);
                intent.putExtra("reservedSeats", reservedSeats);
                intent.putExtra("chooseBus", "Bus 3");
                startActivity(intent);
                finish();
            }
        });

        logout = findViewById(R.id.logoutBtnAvail);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), LogIn.class);
                startActivity(intent);
                finish();
            }
        });

        backAvail = findViewById(R.id.backAvail);
        backAvail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), BusSchedule.class);
                startActivity(intent);
                finish();
            }
        });
    }
}