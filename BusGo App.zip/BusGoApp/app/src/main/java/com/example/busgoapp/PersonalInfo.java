package com.example.busgoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class PersonalInfo extends AppCompatActivity {

    Button buttonPersonalInfo;
    TextView backPersonal, logout;
    EditText name, lastname, email, contactNo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_info);
        
        name = findViewById(R.id.bookName);
        lastname = findViewById(R.id.bookLastName);
        email = findViewById(R.id.bookEmail);
        contactNo = findViewById(R.id.bookContact);

        Bundle extras = getIntent().getExtras();
        String departDate = extras.getString("departDate");
        String destination = extras.getString("destination");
        String departTime = extras.getString("departTime");
        String chooseBus = extras.getString("chooseBus");
        int reservedSeats = extras.getInt("reservedSeats");

//        Toast.makeText(this, departDate + destination + departTime + chooseBus + reservedSeats, Toast.LENGTH_SHORT).show();

        buttonPersonalInfo = findViewById(R.id.personalInfo);
        buttonPersonalInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (
                        !(TextUtils.isEmpty(name.getText())) &&
                        !(TextUtils.isEmpty(lastname.getText())) &&
                        !(TextUtils.isEmpty(email.getText())) &&
                        !(TextUtils.isEmpty(contactNo.getText()))
                ) {
                    String bookName = name.getText().toString();
                    String bookLastName = lastname.getText().toString();
                    String bookEmail = email.getText().toString();
                    String bookContact = contactNo.getText().toString();

                    Intent intent = new Intent(getApplicationContext(), BookSubmit.class);
                    intent.putExtra("departDate", departDate);
                    intent.putExtra("destination", destination);
                    intent.putExtra("departTime", departTime);
                    intent.putExtra("reservedSeats", reservedSeats);
                    intent.putExtra("chooseBus", chooseBus);
                    intent.putExtra("bookName", bookName);
                    intent.putExtra("bookLastName", bookLastName);
                    intent.putExtra("bookEmail", bookEmail);
                    intent.putExtra("bookContact", bookContact);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(PersonalInfo.this, "All field required", Toast.LENGTH_SHORT).show();
                }
                
            }
        });

        logout = findViewById(R.id.logoutPersonal);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), LogIn.class);
                startActivity(intent);
                finish();
            }
        });

        backPersonal = findViewById(R.id.backPersonal);
        backPersonal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentBack = new Intent(getApplicationContext(), BusSchedule.class);
                startActivity(intentBack);
                finish();
            }
        });
    }
}