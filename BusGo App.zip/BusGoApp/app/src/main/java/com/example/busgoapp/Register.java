package com.example.busgoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class Register extends AppCompatActivity {
    EditText username, fname, pass, lname;
    Button regBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        username = findViewById(R.id.regUsername);
        fname = findViewById(R.id.regFName);
        pass = findViewById(R.id.regPass);
        lname = findViewById(R.id.regLName);
        regBtn = findViewById(R.id.regBtn);

        regBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(
                        !(TextUtils.isEmpty(username.getText())) &&
                        !(TextUtils.isEmpty(lname.getText())) &&
                        !(TextUtils.isEmpty(pass.getText())) &&
                        !(TextUtils.isEmpty(fname.getText()))
                ){

                    String regFname = fname.getText().toString();
                    String regUsername = username.getText().toString();
                    String regPass = pass.getText().toString();
                    String regLname = lname.getText().toString();
                    String name = regFname + " " + regLname;

                    RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
                    String url ="http://192.168.100.137/busgo-api/register.php";

                    StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    if(response.equals("success")){
                                        Toast.makeText(Register.this, "Account Registered Successfuly", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(getApplicationContext(), LogIn.class);
                                        startActivity(intent);
                                    } else {
                                        Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                        }
                    }){
                        protected Map<String, String> getParams(){
                            Map<String, String> paramV = new HashMap<>();
                            paramV.put("username", regUsername);
                            paramV.put("name", name);
                            paramV.put("password", regPass);
                            return paramV;
                        }
                    };
                    queue.add(stringRequest);
                } else {
                    Toast.makeText(Register.this, "All Field Required!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        
    }
}