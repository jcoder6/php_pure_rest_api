package com.example.busgoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.HashMap;
import java.util.Map;

public class BookSubmit extends AppCompatActivity {
    TextView logout, backBookBus;
    TextView textViewName, textViewEmail, textViewContact, textViewDest, textViewDtime, textViewDdate, textViewSeats, textViewBus;
    Button buttonBookBus;
    String name, email, contact, destination, depart_time, depart_date, busName, seats;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_submit);

        Bundle extras = getIntent().getExtras();
        String bookName = extras.getString("bookName");
        String bookLastName = extras.getString("bookLastName");
        String bookEmail = extras.getString("bookEmail");
        String bookContact = extras.getString("bookContact");
        String departDate = extras.getString("departDate");
        String bookDestination = extras.getString("destination");
        String departTime = extras.getString("departTime");
        String chooseBus = extras.getString("chooseBus");
        int reservedSeats = extras.getInt("reservedSeats");

        name = toCamelCase(bookName) + " " + toCamelCase(bookLastName);
        email = bookEmail;
        contact = bookContact;
        destination = bookDestination;
        depart_time = departTime;
        depart_date = departDate;
        seats = Integer.toString(reservedSeats);
        busName = chooseBus;

        textViewName = findViewById(R.id.name);
        textViewEmail = findViewById(R.id.email);
        textViewContact = findViewById(R.id.contact);
        textViewDest = findViewById(R.id.destination);
        textViewDtime = findViewById(R.id.depart_time);
        textViewDdate = findViewById(R.id.depart_date);
        textViewSeats = findViewById(R.id.seats);
        textViewBus = findViewById(R.id.busName);

        textViewName.setText("Name: " + name);
        textViewEmail.setText("Email: " + email);
        textViewContact.setText("Contact: " + contact);
        textViewDest.setText("Destination: " + destination);
        textViewBus.setText("Bus Name: " + busName);
        textViewSeats.setText("Booked Seats: " + seats + " seats");
        textViewDtime.setText("Departure Time: " + depart_time);
        textViewDdate.setText("Departure Date: " + depart_date);

        buttonBookBus = findViewById(R.id.bookbus);

        buttonBookBus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
                String url ="http://192.168.100.137/busgo-api/book-bus.php";

                StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                if(response.equals("success")){
                                    Toast.makeText(getApplicationContext(), "Bus Booked Successfuly", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                    startActivity(intent);
                                    finish();
                                } else {
                                    Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }){
                    protected Map<String, String> getParams(){
                        Map<String, String> paramV = new HashMap<>();
                        paramV.put("name", name);
                        paramV.put("email", email);
                        paramV.put("contact", contact);
                        paramV.put("seats", seats);
                        paramV.put("destination", destination);
                        paramV.put("depart_time", depart_time);
                        paramV.put("depart_date", depart_date);
                        paramV.put("bus_name", busName);

                        return paramV;
                    }
                };
                queue.add(stringRequest);
            }
        });

        logout = findViewById(R.id.logoutBtn);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), LogIn.class);
                startActivity(intent);
                finish();
            }
        });

        backBookBus = findViewById(R.id.backBookBus);
        backBookBus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), PersonalInfo.class);
                intent.putExtra("departDate", depart_date);
                intent.putExtra("destination", destination);
                intent.putExtra("departTime", depart_time);
                intent.putExtra("reservedSeats", seats);
                intent.putExtra("chooseBus", busName);
                startActivity(intent);
                finish();
            }
        });
    }

    public static String toCamelCase(String str) {
        String firstLetter = str.substring(0, 1);
        String rest = str.substring(1);
        return firstLetter.toUpperCase() + rest.toLowerCase();
    }
}