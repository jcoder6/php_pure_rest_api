package com.example.busgoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class BusSchedule extends AppCompatActivity {

    Spinner from, to, time;
    EditText selectDate, seats;
    DatePickerDialog picker;
    Button buttonSched;
    String strDate;
    TextView back, logout;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus_schedule);

        selectDate = findViewById(R.id.dateOfDeparture);
        selectDate.setInputType(InputType.TYPE_NULL);
        from = findViewById(R.id.from);
        to = findViewById(R.id.to);
        time = findViewById(R.id.departTime);
        seats = findViewById(R.id.seat);



        selectDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar cldr = Calendar.getInstance();
                int day = cldr.get(Calendar.DAY_OF_MONTH);
                int month = cldr.get(Calendar.MONTH);
                int year = cldr.get(Calendar.YEAR);
                // date picker dialog
                picker = new DatePickerDialog(BusSchedule.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int dateOfMonth) {
                        selectDate.setText(dateOfMonth + "/" + (month + 1) + "/" + year);
                    }
                }, year, month, day);
                picker.show();
            }
        });


        buttonSched = findViewById(R.id.sched);
        buttonSched.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(TextUtils.isEmpty(selectDate.getText())){
                    Toast.makeText(BusSchedule.this, "Please select date...", Toast.LENGTH_SHORT).show();
                } else {
                    String destination = from.getSelectedItem().toString() + " to " + to.getSelectedItem().toString();
                    String departTime = time.getSelectedItem().toString();
                    String rs = seats.getText().toString();
                    Intent intent = new Intent(getApplicationContext(), AvailableBus.class);
                    intent.putExtra("sDate", selectDate.getText().toString());
                    intent.putExtra("destination", destination);
                    intent.putExtra("departTime", departTime);
                    intent.putExtra("reservedSeats", rs);
                    startActivity(intent);
                    finish();
                }
            }
        });

        logout = findViewById(R.id.logoutSched);
        back = findViewById(R.id.backSched);

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), LogIn.class);
                startActivity(intent);
                finish();
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}