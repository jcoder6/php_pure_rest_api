<?php
   $conn = mysqli_connect("localhost", "root", "", "busgo");

   // $data = json_decode(file_get_contents('php://input'));

   if( 
      !empty($_POST['name']) &&      
      !empty($_POST['username']) &&
      !empty($_POST['password'])
   ) {

      // $name = $data->name;
      // $username = $data->username;
      // $password = $data->password;

      $name = $_POST['name'];
      $username = $_POST['username'];
      $password = $_POST['password'];

      if($conn) {
         $sql = "INSERT INTO users(name, username, password) VALUES('$name', '$username', '$password')";

         if(mysqli_query($conn, $sql)){
            echo 'success';
         } else echo 'Something went wrong, Please try again';
      } else echo 'Database Connection Failed';
   } else echo 'Some field are missing';



































