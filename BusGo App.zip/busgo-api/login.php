<?php
   $conn = mysqli_connect("localhost", "root", "", "busgo");
   // $data = json_decode(file_get_contents('php://input'));
   
   $result = array();
   if(!empty($_POST['username']) && !empty($_POST['password'])){
      if($conn){
         // $username = $data->username;
         // $password = $data->password;
         $username = $_POST['username'];
         $password = $_POST['password'];

         $sql = "SELECT * FROM users WHERE username = '$username' && password = '$password'";
         $res = mysqli_query($conn, $sql);
         if($res){
            if(mysqli_num_rows($res) != 0){
               $row = mysqli_fetch_assoc($res);
               $result = array(
                  'status' => 'success',
                  'message' => 'Log in successful',
                  'name' => $row['name']
               );
            } else {
               $result = array(
                  'status' => 'failed',
                  'message' => 'Incorrect username or password',
                  'name' => 'none'
               );
            }
         } else echo 'something went wrong, please try again';
      } else echo 'Database connection failed';
   } else echo 'some fields are missing';

   echo json_encode($result);