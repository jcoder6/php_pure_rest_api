<?php

$conn = mysqli_connect("localhost", "root", "", "busgo");

if(
   !empty($_POST['name']) &&
   !empty($_POST['email']) &&
   !empty($_POST['contact']) &&
   !empty($_POST['seats']) &&
   !empty($_POST['destination']) &&
   !empty($_POST['depart_time']) &&
   !empty($_POST['depart_date']) &&
   !empty($_POST['bus_name'])
) {
   $name = $_POST['name'];
   $email = $_POST['email'];
   $contact = $_POST['contact'];
   $seats = $_POST['seats'];
   $destination = $_POST['destination'];
   $depart_time = $_POST['depart_time'];
   $depart_date = $_POST['depart_date'];
   $busName = $_POST['bus_name'];

   if($conn) {
      $sql = "INSERT INTO booked(
            name, 
            email,
            contact, 
            seats, 
            destination, 
            depart_time, 
            depart_date,
            bus_name
            ) VALUES(
               '$name',
               '$email',
               '$contact',
               '$seats',
               '$destination',
               '$depart_time',
               '$depart_date',
               '$busName'
            )";

      if(mysqli_query($conn, $sql)){
         echo 'success';
      } else echo 'booking bus failed, please try again';
   } else echo 'Database Connection Failed';
} else echo 'Some feilds are missing';
